package com.cts.app.service;

import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cts.app.util.Product;

@Service
public class ProductServiceImpl {
	
	@Value("${product.ms.service.url}")
    private String serviceUrl;

	RestTemplate productRestTemplate = new RestTemplate();

	public Product[] getAllProduct() {
		Product[] productList = productRestTemplate.getForObject(serviceUrl + "products", Product[].class);
		return productList;
	}

	public Product getProduct(int productId) {
		Product product = productRestTemplate.getForObject(serviceUrl + "product/" + productId, Product.class);
		return product;
	}

	public String addProduct(Product product) throws URISyntaxException {
		
	    final String baseUrl = serviceUrl + "product";
        URI uri = new URI(baseUrl);
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Product> request = new HttpEntity<>(product, headers);
        ResponseEntity<String> result = productRestTemplate.postForEntity(uri, request,String.class);
		return result.getBody();
	}

	public String updateProduct(Product product) {
		productRestTemplate.put(serviceUrl + "product/" + product.getId(), product);
		return "Product updated scussessfully";
	}

	public void deleteProduct(int productId) {
		HttpHeaders headers = new HttpHeaders();
	    HttpEntity<Product> entity = new HttpEntity<Product>(headers);
		productRestTemplate.exchange(serviceUrl + "product/" + productId, HttpMethod.DELETE, entity, String.class);
	}

}
