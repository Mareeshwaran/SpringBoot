package com.cts.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.app.service.ProductServiceImpl;
import com.cts.app.util.Product;

@Controller
public class ProductController {

	@Autowired
	ProductServiceImpl productService;

	@GetMapping(value = { "/", "/products" })
	public String findAllProducts(Model model) {
		Product[] productList = productService.getAllProduct();
		model.addAttribute("productList", productList);
		return "Product";
	}

	@PostMapping("/addProduct")
	public String addProduct(Model model, @ModelAttribute("product") Product product) throws Exception {
		String response = null;
		if (product != null && product.getProductCode() != null && product.getProductCode() != "")
			response = productService.addProduct(product);
		else
			response = "Please enter all the fields";
		model.addAttribute("message", response);
		return "AddProduct";
	}

	@GetMapping("/addProductPage")
	public String addProduct(Model model) {
		model.addAttribute("message", "");
		model.addAttribute("product", new Product());
		return "AddProduct";
	}

	@PostMapping("/updateProduct")
	public String updateProduct(Model model, @ModelAttribute("product") Product product) {
		String response = null;
		if (product != null && product.getProductCode() != null && product.getProductCode() != "")
			response = productService.updateProduct(product);
		else
			response = "Please enter all the fields";
		model.addAttribute("message", response);
		return "UpdateProduct";
	}

	@GetMapping("/updatePage")
	public String update(Model model, @RequestParam("productId") int productId) {

		Product product = productService.getProduct(productId);
		model.addAttribute("product", product);
		model.addAttribute("message", "");
		return "UpdateProduct";
	}

	@GetMapping("/delete")
	public String deleteProduct(Model model, @RequestParam("productId") int productId) {
		productService.deleteProduct(productId);
		Product[] productList = productService.getAllProduct();
		model.addAttribute("productList", productList);
		return "Product";
	}

}
