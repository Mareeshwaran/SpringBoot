package com.cts.app.controller;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;

@Endpoint(id = "custom")
public class CustomEndPoint implements HealthIndicator {
	private final String message_key = "Custom Helth check service";

	@Override
	@ReadOperation
	public Health health() {
		if (!isRunningService()) {
			return Health.down().withDetail(message_key, "Not Available").build();
		}
		return Health.up().withDetail(message_key, "Available").build();
	}

	private Boolean isRunningService() {
		Boolean isRunning = true;
		return isRunning;
	}
}
