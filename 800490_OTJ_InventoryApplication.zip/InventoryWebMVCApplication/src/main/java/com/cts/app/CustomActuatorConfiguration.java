package com.cts.app;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cts.app.controller.CustomEndPoint;

@Configuration
public class CustomActuatorConfiguration {

	@Bean
	public CustomEndPoint customEndPoint() {
		return new CustomEndPoint();
	}
}
