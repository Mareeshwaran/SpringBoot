package com.cts.product.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cts.product.exception.ProductException;

@ControllerAdvice
public class ExceptionController {
	@ExceptionHandler(value = Exception.class)
	@ResponseBody
	public String handleException(ProductException ex) {
		return ex.getMessage();
	}
}
