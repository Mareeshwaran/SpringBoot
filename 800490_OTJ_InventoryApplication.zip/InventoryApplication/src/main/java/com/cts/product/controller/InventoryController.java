package com.cts.product.controller;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.product.entity.Product;
import com.cts.product.service.InventoryServiceImpl;

/**
 * @Description Requirement 1: Allow inventory managers in the company to view/add/update/delete products in the inventory. 
 *              a) Get list of all products in the inventory 
 *              b) Add a new product 
 *              c) Delete existing product 
 *              d) Get the price of a given product. Since this end-point is used to check price periodically,
 *                 cache the HTTP response for 30 minutes. 
 *              e) Update price of an existing product
 */
@RestController
public class InventoryController {
	
	Logger logger = LoggerFactory.getLogger(InventoryController.class);

	@Autowired
	InventoryServiceImpl inventoryServiceImpl;

	@RequestMapping(value = "/api/products", method = RequestMethod.GET)
	@ResponseBody
	public List<Product> findAllProuct() {
		return inventoryServiceImpl.findAll();
	}

	@RequestMapping(value = "/api/product/{productId}", method = RequestMethod.GET)
	@ResponseBody
	public Product findProduct(@PathVariable("productId") int productId) {
		logger.debug("Request productId: {} ", productId);
		return inventoryServiceImpl.viewProduct(productId);
	}

	@RequestMapping(value = "/api/product/{productId}/price", method = RequestMethod.GET)
	@ResponseBody
	@Cacheable("price")
	public double getPrice(@PathVariable("productId") int productId) {
		logger.debug("Request productId: {} ", productId);
		return inventoryServiceImpl.getPrice(productId);
	}

	@RequestMapping(value = "/api/product", method = RequestMethod.POST)
	@ResponseBody
	public String addNewProduct(@RequestBody Product product) {
		return inventoryServiceImpl.addProduct(product);
	}

	@RequestMapping(value = "/api/product/{productId}", method = RequestMethod.PUT)
	@ResponseBody
	public Product updateProduct(@RequestBody Product product, @PathVariable("productId") int productId) {
		logger.debug("Request productId: {} ", productId);
		return inventoryServiceImpl.updateProduct(product, productId);
	}

	@RequestMapping(value = "/api/product/{productId}", method = RequestMethod.DELETE)
	@ResponseBody
	public String deleteProduct(@PathVariable("productId") int productId) {
		logger.debug("Request productId: {} ", productId);
		return inventoryServiceImpl.deleteProduct(productId);
	}

	/**
	 * @Description Requirement 4 : Retrieve product details for a given id, if the
	 *              id is 1 return a http code of 302, else set the response status
	 *              as 200 and return the product details
	 * @param response
	 * @param productId
	 * @return Product details
	 */
	@RequestMapping(value = "/api/promotion/product/{productId}", method = RequestMethod.GET)
	public Product getProductForPromotion(HttpServletResponse response, @PathVariable("productId") int productId) {
		logger.debug("Request productId: {} ", productId);
		if (productId == 1) {
			response.setStatus(302);
			return null;
		} else {
			response.setStatus(200);
			return inventoryServiceImpl.viewProduct(productId);
		}
	}
	
	/**
	 * @param productId
	 * @param price
	 * @return
	 */
	@RequestMapping(value = "/api/product/{productId}/price/{price}", method = RequestMethod.PUT)
	public Product updatePrice(@PathVariable("productId") int productId, @PathVariable("price") double price) {
		logger.debug("Request productId: {} ", productId);
		return inventoryServiceImpl.updatePrice(productId, price);
	}
}
