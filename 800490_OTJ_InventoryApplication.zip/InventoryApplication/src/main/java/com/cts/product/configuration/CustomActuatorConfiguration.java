package com.cts.product.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cts.product.controller.CustomEndPoint;

@Configuration
public class CustomActuatorConfiguration {

	@Bean
	public CustomEndPoint customEndPoint() {
		return new CustomEndPoint();
	}
}
