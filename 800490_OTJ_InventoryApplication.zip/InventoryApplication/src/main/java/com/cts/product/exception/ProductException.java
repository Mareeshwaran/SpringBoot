package com.cts.product.exception;

public class ProductException extends RuntimeException {
	private static final long serialVersionUID = -4613936049695703020L;
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public ProductException(String message) {
		super();
		this.message = message;
	}

}
