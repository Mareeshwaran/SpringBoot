package com.cts.product.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
@Entity
@SequenceGenerator(name="seq", initialValue=1, allocationSize=100)
public class Product {
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq")
	@Id
	private int id;
	private String productCode;
	private String name;
	private double price;
	private String description;
	private int qty; 
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public Product() {
		super();
	}
	public Product(String productCode, String name, double price, String description, int qty) {
		super();
		this.productCode = productCode;
		this.name = name;
		this.price = price;
		this.description = description;
		this.qty = qty;
	}
}
