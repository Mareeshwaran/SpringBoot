package com.cts.product.configuration;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.cts.product.entity.Product;
import com.cts.product.service.InventoryServiceImpl;

@Component
public class DataLoaderOnStartUp implements CommandLineRunner {

	Logger logger = LoggerFactory.getLogger(DataLoaderOnStartUp.class);

	private InventoryServiceImpl inventoryServiceImpl;

	@Autowired
	public DataLoaderOnStartUp(InventoryServiceImpl inventoryServiceImpl) {
		this.inventoryServiceImpl = inventoryServiceImpl;
	}

	@Override
	public void run(String... args) throws Exception {
		logger.info("Loading mocked data into database on startup!!!");
		List<Product> products = Arrays.asList(new Product("M2245", "Redmi", 15000.0, "Redmi Note 9 Pro", 500),
				new Product("M4566", "iPhone", 90000.0, "iPhone 11 Pro Max", 500),
				new Product("M2453", "OnePlus", 45000.0, "OnePlus 8T 5G", 100),
				new Product("M1189", "Samsung", 20000.0, "Samsung Galaxy M31", 500),
				new Product("M4564", "Oppo", 15000.0, "Oppo A5 2020", 300),
				new Product("M2248", "Redmi", 18000.0, "Redmi Note 8 Pro", 500));
		inventoryServiceImpl.saveAllProducts(products);
	}

}