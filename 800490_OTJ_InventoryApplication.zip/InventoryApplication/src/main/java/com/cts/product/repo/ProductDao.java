package com.cts.product.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.product.entity.Product;

@Repository
public interface ProductDao extends JpaRepository<Product, Integer> {

	Product findByProductCode(String productCode);
	Product findById(int productId);
}
