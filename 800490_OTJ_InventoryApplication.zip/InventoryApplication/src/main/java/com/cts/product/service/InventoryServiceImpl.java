package com.cts.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.cts.product.entity.Product;
import com.cts.product.exception.ProductException;
import com.cts.product.repo.ProductDao;

@Service
public class InventoryServiceImpl {

	@Autowired
	ProductDao productDao;

	@Value("#{'${banned-products}'.split(',')}")
	private List<String> bannedProdcutList;

	/**
	 * @param product
	 * @return string
	 */
	public String addProduct(Product product) {
		if (bannedProdcutList != null && !bannedProdcutList.isEmpty() && product.getName() != null
				&& !bannedProdcutList.contains(product.getName().toUpperCase())) {
			productDao.save(product);
			return "Product has been added successfully!!!";
		} else {
			throw new ProductException("Sorry!!! We can't add this product.Since,its a banned product");
		}
	}

	/**
	 * @param productId
	 * @return product
	 */
	public Product viewProduct(int productId) {
		return productDao.findById(productId);
	}

	/**
	 * @return list of product
	 */
	public List<Product> findAll() {
		return productDao.findAll();
	}

	
	/**
	 * @param productId
	 * @return price
	 */
	public double getPrice(int productId) {
		Product product = productDao.findById(productId);
		return product.getPrice();
	}

	/**
	 * @param product
	 * @param productId
	 * @return updated product details
	 */
	public Product updateProduct(Product product, int productId) {
		Product existingProduct = null;
		if(productId != 0) {
			existingProduct = productDao.findById(productId);
			existingProduct.setProductCode(product.getProductCode());
			existingProduct.setName(product.getName());
			existingProduct.setDescription(product.getDescription());
			existingProduct.setPrice(product.getPrice());
			existingProduct.setQty(product.getQty());
			productDao.save(existingProduct);
		}
		return existingProduct;
	}

	/**
	 * @param productId
	 * @param price
	 * @return product
	 */
	public Product updatePrice(int productId, double price) {
		Product product = null;
		if(productId != 0) {
			product = productDao.findById(productId);
			product.setPrice(price);
			productDao.save(product);
		}
		return product;
	}
	
	/**
	 * @param productId
	 * @return string
	 */
	public String deleteProduct(int productId) {
		try {
			productDao.deleteById(productId);
			return "Product has been deleted!!!";
		} catch (Exception e) {
			return "Unable to delete the product at this time. Please try again later!!!";
		}
	}
	
	/**
	 * @param productList
	 */
	public void saveAllProducts(List<Product> productList) {
		productDao.saveAll(productList);
	}
}
