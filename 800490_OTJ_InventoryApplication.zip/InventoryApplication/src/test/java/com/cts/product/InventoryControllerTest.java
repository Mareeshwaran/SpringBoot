package com.cts.product;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import com.cts.product.entity.Product;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class InventoryControllerTest {

	@LocalServerPort
	int randomServerPort;

	@Test
	public void testFindAllProuct() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		final String baseUrl = "http://localhost:" + randomServerPort + "/api/products";
		URI uri = new URI(baseUrl);
		ResponseEntity<Product[]> result = restTemplate.getForEntity(uri, Product[].class);
		Assert.assertEquals(200, result.getStatusCodeValue());
	}

	@Test
	public void testFindProuct() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		int productId = 2;
		final String baseUrl = "http://localhost:" + randomServerPort + "/api/product/" + productId;
		URI uri = new URI(baseUrl);
		ResponseEntity<Product> result = restTemplate.getForEntity(uri, Product.class);
		Assert.assertEquals(200, result.getStatusCodeValue());
		Assert.assertEquals(true, result.getBody().getProductCode() != null);
	}

	@Test
	public void testGetPrice() throws URISyntaxException {
		RestTemplate restTemplate = new RestTemplate();
		int productId = 2;
		final String baseUrl = "http://localhost:" + randomServerPort + "/api/product/" + productId + "/price";
		URI uri = new URI(baseUrl);
		ResponseEntity<Double> result = restTemplate.getForEntity(uri, Double.class);
		Assert.assertEquals(200, result.getStatusCodeValue());
	}

	@Test
	public void testAddProduct() throws URISyntaxException {
		Product product = new Product();
		product.setProductCode("P3456");
		product.setName("Mobile");
		product.setDescription("Redmi Note 8");
		product.setPrice(20000);
		product.setQty(200);
		RestTemplate restTemplate = new RestTemplate();
		final String baseUrl = "http://localhost:" + randomServerPort + "/api/product";
		URI uri = new URI(baseUrl);
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<Product> request = new HttpEntity<>(product, headers);
		ResponseEntity<String> result = restTemplate.postForEntity(uri, request, String.class);
		Assert.assertEquals(200, result.getStatusCodeValue());
		Assert.assertEquals("Product has been added successfully!!!", result.getBody().toString());
	}

	@Test
	public void testUpdateProduct() throws URISyntaxException {
		Product product = new Product();
		product.setProductCode("MI456");
		product.setName("Redmi");
		product.setDescription("Redmi Note 10");
		product.setPrice(20000);
		product.setQty(200);
		int productId = 1;
		RestTemplate restTemplate = new RestTemplate();
		final String baseUrl = "http://localhost:" + randomServerPort + "/api/product/" + productId;
		URI uri = new URI(baseUrl);
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<Product> request = new HttpEntity<>(product, headers);
		ResponseEntity<Product> result = restTemplate.exchange(uri, HttpMethod.PUT, request, Product.class);
		Assert.assertEquals(200, result.getStatusCodeValue());
	}

	@Test
	public void testDeleteProduct() throws URISyntaxException {
		int productId = 6;
		RestTemplate restTemplate = new RestTemplate();
		final String baseUrl = "http://localhost:" + randomServerPort + "/api/product/" + productId;
		URI uri = new URI(baseUrl);
		restTemplate.delete(uri);
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<Product> request = new HttpEntity<>(new Product(), headers);
		ResponseEntity<String> result = restTemplate.exchange(uri, HttpMethod.DELETE, request, String.class);
		Assert.assertEquals(200, result.getStatusCodeValue());
	}

	@Test
	public void testGetProductForPromotion() throws URISyntaxException {
		int productId = 1;
		RestTemplate restTemplate = new RestTemplate();
		final String baseUrl = "http://localhost:" + randomServerPort + "/api/promotion/product/" + productId;
		URI uri = new URI(baseUrl);
		ResponseEntity<Product> result = restTemplate.getForEntity(uri, Product.class);
		Assert.assertEquals(302, result.getStatusCodeValue());
	}

	@Test
	public void testUpdatePrice() throws URISyntaxException {
		int productId = 1;
		double price = 25000.0;
		RestTemplate restTemplate = new RestTemplate();
		final String baseUrl = "http://localhost:" + randomServerPort + "/api/product/" + productId + "/price/" + price;
		URI uri = new URI(baseUrl);
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<Product> request = new HttpEntity<>(headers);
		ResponseEntity<Product> result = restTemplate.exchange(uri, HttpMethod.PUT, request, Product.class);
		Assert.assertEquals(200, result.getStatusCodeValue());
	}

}
